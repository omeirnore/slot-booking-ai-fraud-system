import express from "express";
import fs from "fs";
import path from "path";
import { v4 as uuid } from "uuid";

const router = express.Router();
const file = path.resolve("data/bookings.json");

function read() {
  if (!fs.existsSync(file)) return [];
  return JSON.parse(fs.readFileSync(file));
}

function write(data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

router.get("/", (req, res) => {
  res.json(read());
});

router.post("/", (req, res) => {
  const { name, date, time, service } = req.body;
  if (!name || !date || !time || !service) return res.status(400).json({ error: "Missing fields" });

  const bookings = read();
  const newBooking = { id: uuid(), name, date, time, service };
  bookings.push(newBooking);
  write(bookings);

  res.status(201).json(newBooking);
});

export default router;
