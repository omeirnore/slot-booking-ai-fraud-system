import express from "express";
import fs from "fs";
import path from "path";
import { v4 as uuid } from "uuid";

const router = express.Router();
const file = path.resolve("data/contacts.json");

function read() {
  if (!fs.existsSync(file)) return [];
  return JSON.parse(fs.readFileSync(file));
}

function write(data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

router.post("/", (req, res) => {
  const { firstName, lastName, email, phone, company, message } = req.body;
  if (!firstName || !email || !message) return res.status(400).json({ error: "Missing fields" });

  const contacts = read();
  const newContact = { id: uuid(), firstName, lastName, email, phone, company, message };
  contacts.push(newContact);
  write(contacts);

  res.status(201).json({ success: true, data: newContact });
});

export default router;
